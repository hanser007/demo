package com.yyb.Service;

public interface StuService {

    public boolean getPS(String username, String password);

}
